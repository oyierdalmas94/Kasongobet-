
function verifyOTP() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('game-ui').style.display = 'block';
  document.getElementById('content-area').innerHTML = "<h3>Welcome to AviatedX Demo!</h3><p>Daily Demo Balance: KES 10,000</p><p>🚀 Game launching...</p>";
}
function toggleGame() {
  document.getElementById('content-area').innerHTML = "<h3>🚀 AviatedX</h3><p>Demo & Real Accounts Coming Soon</p>";
}
function toggleKasongo() {
  document.getElementById('content-area').innerHTML = "<h3>KasongoBet</h3><p>Odds & Betting Panel</p>";
}
